/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QStackedWidget *stackedWidget;
    QWidget *page_1;
    QLabel *logoLabel;
    QLabel *label;
    QLineEdit *usernameLineEdit;
    QLineEdit *passwordLineEdit;
    QPushButton *loginButton;
    QLabel *label_3;
    QWidget *page_2;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *openCheckInDialog;
    QSpacerItem *horizontalSpacer;
    QPushButton *openBreakDialog;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *openMapDialog;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *openIncidentDialog;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *openSubmissionDialog;
    QSpacerItem *horizontalSpacer_8;
    QPushButton *generateReport;
    QSpacerItem *horizontalSpacer_9;
    QLabel *label_2;
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *TNum;
    QLabel *TName;
    QLabel *CNum;
    QLabel *ERoom;
    QLabel *NumSeats;
    QLabel *NumEVersions;
    QLabel *EVersions;
    QLabel *Stime;
    QLabel *ETime;
    QLabel *termNameValueLabel;
    QLabel *termNumberValueLabel;
    QLabel *courseNumberValueLabel;
    QLabel *examRoomValueLabel;
    QLabel *numSeatsValueLabel;
    QLabel *numVersionsValueLabel;
    QLabel *examVersionsValueLabel;
    QLabel *startTimeValueLabel;
    QLabel *endTimeValueLabel;
    QPushButton *logOutButton;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1280, 720);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName("verticalLayout");
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName("stackedWidget");
        page_1 = new QWidget();
        page_1->setObjectName("page_1");
        logoLabel = new QLabel(page_1);
        logoLabel->setObjectName("logoLabel");
        logoLabel->setGeometry(QRect(380, 40, 485, 116));
        QSizePolicy sizePolicy(QSizePolicy::Policy::Fixed, QSizePolicy::Policy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(logoLabel->sizePolicy().hasHeightForWidth());
        logoLabel->setSizePolicy(sizePolicy);
        logoLabel->setMinimumSize(QSize(485, 0));
        logoLabel->setPixmap(QPixmap(QString::fromUtf8(":/media/img/UWO_Horizontal_Full.png")));
        label = new QLabel(page_1);
        label->setObjectName("label");
        label->setGeometry(QRect(460, 190, 390, 32));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        QFont font;
        font.setPointSize(20);
        label->setFont(font);
        usernameLineEdit = new QLineEdit(page_1);
        usernameLineEdit->setObjectName("usernameLineEdit");
        usernameLineEdit->setGeometry(QRect(563, 300, 125, 22));
        sizePolicy.setHeightForWidth(usernameLineEdit->sizePolicy().hasHeightForWidth());
        usernameLineEdit->setSizePolicy(sizePolicy);
        passwordLineEdit = new QLineEdit(page_1);
        passwordLineEdit->setObjectName("passwordLineEdit");
        passwordLineEdit->setGeometry(QRect(563, 340, 125, 22));
        sizePolicy.setHeightForWidth(passwordLineEdit->sizePolicy().hasHeightForWidth());
        passwordLineEdit->setSizePolicy(sizePolicy);
        passwordLineEdit->setEchoMode(QLineEdit::EchoMode::Normal);
        loginButton = new QPushButton(page_1);
        loginButton->setObjectName("loginButton");
        loginButton->setEnabled(true);
        loginButton->setGeometry(QRect(585, 390, 80, 22));
        sizePolicy.setHeightForWidth(loginButton->sizePolicy().hasHeightForWidth());
        loginButton->setSizePolicy(sizePolicy);
        label_3 = new QLabel(page_1);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(-10, 640, 1281, 51));
        sizePolicy.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setPointSize(9);
        label_3->setFont(font1);
        stackedWidget->addWidget(page_1);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        horizontalLayoutWidget = new QWidget(page_2);
        horizontalLayoutWidget->setObjectName("horizontalLayoutWidget");
        horizontalLayoutWidget->setGeometry(QRect(0, 629, 1261, 71));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        openCheckInDialog = new QPushButton(horizontalLayoutWidget);
        openCheckInDialog->setObjectName("openCheckInDialog");
        QSizePolicy sizePolicy1(QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(openCheckInDialog->sizePolicy().hasHeightForWidth());
        openCheckInDialog->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(openCheckInDialog);

        horizontalSpacer = new QSpacerItem(5, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        horizontalLayout->addItem(horizontalSpacer);

        openBreakDialog = new QPushButton(horizontalLayoutWidget);
        openBreakDialog->setObjectName("openBreakDialog");
        sizePolicy1.setHeightForWidth(openBreakDialog->sizePolicy().hasHeightForWidth());
        openBreakDialog->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(openBreakDialog);

        horizontalSpacer_2 = new QSpacerItem(5, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        horizontalLayout->addItem(horizontalSpacer_2);

        openMapDialog = new QPushButton(horizontalLayoutWidget);
        openMapDialog->setObjectName("openMapDialog");
        sizePolicy1.setHeightForWidth(openMapDialog->sizePolicy().hasHeightForWidth());
        openMapDialog->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(openMapDialog);

        horizontalSpacer_3 = new QSpacerItem(5, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        horizontalLayout->addItem(horizontalSpacer_3);

        openIncidentDialog = new QPushButton(horizontalLayoutWidget);
        openIncidentDialog->setObjectName("openIncidentDialog");
        sizePolicy1.setHeightForWidth(openIncidentDialog->sizePolicy().hasHeightForWidth());
        openIncidentDialog->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(openIncidentDialog);

        horizontalSpacer_7 = new QSpacerItem(5, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        horizontalLayout->addItem(horizontalSpacer_7);

        openSubmissionDialog = new QPushButton(horizontalLayoutWidget);
        openSubmissionDialog->setObjectName("openSubmissionDialog");
        sizePolicy1.setHeightForWidth(openSubmissionDialog->sizePolicy().hasHeightForWidth());
        openSubmissionDialog->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(openSubmissionDialog);

        horizontalSpacer_8 = new QSpacerItem(5, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        horizontalLayout->addItem(horizontalSpacer_8);

        generateReport = new QPushButton(horizontalLayoutWidget);
        generateReport->setObjectName("generateReport");
        sizePolicy1.setHeightForWidth(generateReport->sizePolicy().hasHeightForWidth());
        generateReport->setSizePolicy(sizePolicy1);

        horizontalLayout->addWidget(generateReport);

        horizontalSpacer_9 = new QSpacerItem(5, 0, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Fixed);

        horizontalLayout->addItem(horizontalSpacer_9);

        label_2 = new QLabel(page_2);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(-10, 70, 1281, 32));
        sizePolicy.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy);
        label_2->setFont(font);
        formLayoutWidget = new QWidget(page_2);
        formLayoutWidget->setObjectName("formLayoutWidget");
        formLayoutWidget->setGeometry(QRect(130, 180, 971, 301));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName("formLayout");
        formLayout->setFieldGrowthPolicy(QFormLayout::FieldGrowthPolicy::FieldsStayAtSizeHint);
        formLayout->setLabelAlignment(Qt::AlignmentFlag::AlignLeading);
        formLayout->setFormAlignment(Qt::AlignmentFlag::AlignLeading|Qt::AlignmentFlag::AlignLeft|Qt::AlignmentFlag::AlignTop);
        formLayout->setContentsMargins(0, 0, 0, 0);
        TNum = new QLabel(formLayoutWidget);
        TNum->setObjectName("TNum");
        QFont font2;
        font2.setPointSize(14);
        TNum->setFont(font2);

        formLayout->setWidget(0, QFormLayout::LabelRole, TNum);

        TName = new QLabel(formLayoutWidget);
        TName->setObjectName("TName");
        TName->setFont(font2);

        formLayout->setWidget(1, QFormLayout::LabelRole, TName);

        CNum = new QLabel(formLayoutWidget);
        CNum->setObjectName("CNum");
        CNum->setFont(font2);

        formLayout->setWidget(2, QFormLayout::LabelRole, CNum);

        ERoom = new QLabel(formLayoutWidget);
        ERoom->setObjectName("ERoom");
        ERoom->setFont(font2);

        formLayout->setWidget(3, QFormLayout::LabelRole, ERoom);

        NumSeats = new QLabel(formLayoutWidget);
        NumSeats->setObjectName("NumSeats");
        NumSeats->setFont(font2);

        formLayout->setWidget(4, QFormLayout::LabelRole, NumSeats);

        NumEVersions = new QLabel(formLayoutWidget);
        NumEVersions->setObjectName("NumEVersions");
        NumEVersions->setFont(font2);

        formLayout->setWidget(5, QFormLayout::LabelRole, NumEVersions);

        EVersions = new QLabel(formLayoutWidget);
        EVersions->setObjectName("EVersions");
        EVersions->setFont(font2);

        formLayout->setWidget(6, QFormLayout::LabelRole, EVersions);

        Stime = new QLabel(formLayoutWidget);
        Stime->setObjectName("Stime");
        Stime->setFont(font2);

        formLayout->setWidget(7, QFormLayout::LabelRole, Stime);

        ETime = new QLabel(formLayoutWidget);
        ETime->setObjectName("ETime");
        ETime->setFont(font2);

        formLayout->setWidget(8, QFormLayout::LabelRole, ETime);

        termNameValueLabel = new QLabel(formLayoutWidget);
        termNameValueLabel->setObjectName("termNameValueLabel");
        termNameValueLabel->setFont(font2);

        formLayout->setWidget(1, QFormLayout::FieldRole, termNameValueLabel);

        termNumberValueLabel = new QLabel(formLayoutWidget);
        termNumberValueLabel->setObjectName("termNumberValueLabel");
        termNumberValueLabel->setFont(font2);

        formLayout->setWidget(0, QFormLayout::FieldRole, termNumberValueLabel);

        courseNumberValueLabel = new QLabel(formLayoutWidget);
        courseNumberValueLabel->setObjectName("courseNumberValueLabel");
        courseNumberValueLabel->setFont(font2);

        formLayout->setWidget(2, QFormLayout::FieldRole, courseNumberValueLabel);

        examRoomValueLabel = new QLabel(formLayoutWidget);
        examRoomValueLabel->setObjectName("examRoomValueLabel");
        examRoomValueLabel->setFont(font2);

        formLayout->setWidget(3, QFormLayout::FieldRole, examRoomValueLabel);

        numSeatsValueLabel = new QLabel(formLayoutWidget);
        numSeatsValueLabel->setObjectName("numSeatsValueLabel");
        numSeatsValueLabel->setFont(font2);

        formLayout->setWidget(4, QFormLayout::FieldRole, numSeatsValueLabel);

        numVersionsValueLabel = new QLabel(formLayoutWidget);
        numVersionsValueLabel->setObjectName("numVersionsValueLabel");
        numVersionsValueLabel->setFont(font2);

        formLayout->setWidget(5, QFormLayout::FieldRole, numVersionsValueLabel);

        examVersionsValueLabel = new QLabel(formLayoutWidget);
        examVersionsValueLabel->setObjectName("examVersionsValueLabel");
        examVersionsValueLabel->setFont(font2);

        formLayout->setWidget(6, QFormLayout::FieldRole, examVersionsValueLabel);

        startTimeValueLabel = new QLabel(formLayoutWidget);
        startTimeValueLabel->setObjectName("startTimeValueLabel");
        startTimeValueLabel->setFont(font2);

        formLayout->setWidget(7, QFormLayout::FieldRole, startTimeValueLabel);

        endTimeValueLabel = new QLabel(formLayoutWidget);
        endTimeValueLabel->setObjectName("endTimeValueLabel");
        endTimeValueLabel->setFont(font2);

        formLayout->setWidget(8, QFormLayout::FieldRole, endTimeValueLabel);

        logOutButton = new QPushButton(page_2);
        logOutButton->setObjectName("logOutButton");
        logOutButton->setGeometry(QRect(1070, 30, 170, 40));
        stackedWidget->addWidget(page_2);

        verticalLayout->addWidget(stackedWidget);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Login", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Exam Management System", nullptr));
        usernameLineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Username", nullptr));
        passwordLineEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Password", nullptr));
        loginButton->setText(QCoreApplication::translate("MainWindow", "Log in", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">This Qt application was developed by Group 66 as part of the CS3307 course evaluation for Winter 2025 at Western University.</p><p align=\"center\">Authors: Andy Dai, Allen Pan, Minh Pham, Kohei Kubota</p></body></html>", nullptr));
        openCheckInDialog->setText(QCoreApplication::translate("MainWindow", "Open Check In", nullptr));
        openBreakDialog->setText(QCoreApplication::translate("MainWindow", "Take Break", nullptr));
        openMapDialog->setText(QCoreApplication::translate("MainWindow", "Seating Map", nullptr));
        openIncidentDialog->setText(QCoreApplication::translate("MainWindow", "Report Incident", nullptr));
        openSubmissionDialog->setText(QCoreApplication::translate("MainWindow", "Student Submission", nullptr));
        generateReport->setText(QCoreApplication::translate("MainWindow", "Generate Report", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\">Exam Management System (Group 66)</p></body></html>", nullptr));
        TNum->setText(QCoreApplication::translate("MainWindow", "Term Number:", nullptr));
        TName->setText(QCoreApplication::translate("MainWindow", "Term Name:", nullptr));
        CNum->setText(QCoreApplication::translate("MainWindow", "Course Number:", nullptr));
        ERoom->setText(QCoreApplication::translate("MainWindow", "Exam Room:", nullptr));
        NumSeats->setText(QCoreApplication::translate("MainWindow", "Number of Seats:", nullptr));
        NumEVersions->setText(QCoreApplication::translate("MainWindow", "Number of Exam Versions: ", nullptr));
        EVersions->setText(QCoreApplication::translate("MainWindow", "Exam Verions:", nullptr));
        Stime->setText(QCoreApplication::translate("MainWindow", "Start Time", nullptr));
        ETime->setText(QCoreApplication::translate("MainWindow", "End Time", nullptr));
        termNameValueLabel->setText(QString());
        termNumberValueLabel->setText(QString());
        courseNumberValueLabel->setText(QString());
        examRoomValueLabel->setText(QString());
        numSeatsValueLabel->setText(QString());
        numVersionsValueLabel->setText(QString());
        examVersionsValueLabel->setText(QString());
        startTimeValueLabel->setText(QString());
        endTimeValueLabel->setText(QString());
        logOutButton->setText(QCoreApplication::translate("MainWindow", "Log Out", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
