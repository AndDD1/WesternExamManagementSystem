/********************************************************************************
** Form generated from reading UI file 'generatereport.ui'
**
** Created by: Qt User Interface Compiler version 6.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GENERATEREPORT_H
#define UI_GENERATEREPORT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_generatereport
{
public:
    QLabel *Title;
    QWidget *formLayoutWidget;
    QFormLayout *ExamDetailsLayout;
    QLabel *Exam;
    QLabel *Room;
    QLabel *Date;
    QLabel *dateValueLabel;
    QLabel *StartTime;
    QLabel *startTimeValueLabel;
    QLabel *EndTime;
    QLabel *endTimeValueLabel;
    QLabel *examValueLabel;
    QLabel *roomValueLabel;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *ProctorsLayout;
    QLabel *Proctors;
    QLabel *proctorValueLabel;
    QWidget *formLayoutWidget_2;
    QFormLayout *ExamSummaryLayout;
    QLabel *TotalPresent;
    QLabel *totalPresentValueLabel;
    QLabel *EarlySubmissions;
    QLabel *earlySubmissionsValueLabel;
    QLabel *BreaksTaken;
    QLabel *breaksValueLabel;
    QLabel *Summary;
    QWidget *verticalLayoutWidget_3;
    QVBoxLayout *IncidentReport;
    QLabel *label_2;
    QPushButton *GenerateReportButton;
    QPushButton *pushButton;
    QLabel *label;

    void setupUi(QWidget *generatereport)
    {
        if (generatereport->objectName().isEmpty())
            generatereport->setObjectName("generatereport");
        generatereport->resize(904, 878);
        Title = new QLabel(generatereport);
        Title->setObjectName("Title");
        Title->setGeometry(QRect(380, 20, 171, 51));
        QFont font;
        font.setPointSize(18);
        Title->setFont(font);
        Title->setScaledContents(false);
        formLayoutWidget = new QWidget(generatereport);
        formLayoutWidget->setObjectName("formLayoutWidget");
        formLayoutWidget->setGeometry(QRect(50, 110, 331, 141));
        ExamDetailsLayout = new QFormLayout(formLayoutWidget);
        ExamDetailsLayout->setObjectName("ExamDetailsLayout");
        ExamDetailsLayout->setContentsMargins(0, 0, 0, 0);
        Exam = new QLabel(formLayoutWidget);
        Exam->setObjectName("Exam");
        QFont font1;
        font1.setPointSize(12);
        Exam->setFont(font1);

        ExamDetailsLayout->setWidget(0, QFormLayout::LabelRole, Exam);

        Room = new QLabel(formLayoutWidget);
        Room->setObjectName("Room");
        Room->setFont(font1);

        ExamDetailsLayout->setWidget(1, QFormLayout::LabelRole, Room);

        Date = new QLabel(formLayoutWidget);
        Date->setObjectName("Date");
        Date->setFont(font1);

        ExamDetailsLayout->setWidget(2, QFormLayout::LabelRole, Date);

        dateValueLabel = new QLabel(formLayoutWidget);
        dateValueLabel->setObjectName("dateValueLabel");

        ExamDetailsLayout->setWidget(2, QFormLayout::FieldRole, dateValueLabel);

        StartTime = new QLabel(formLayoutWidget);
        StartTime->setObjectName("StartTime");
        StartTime->setFont(font1);

        ExamDetailsLayout->setWidget(3, QFormLayout::LabelRole, StartTime);

        startTimeValueLabel = new QLabel(formLayoutWidget);
        startTimeValueLabel->setObjectName("startTimeValueLabel");

        ExamDetailsLayout->setWidget(3, QFormLayout::FieldRole, startTimeValueLabel);

        EndTime = new QLabel(formLayoutWidget);
        EndTime->setObjectName("EndTime");
        EndTime->setFont(font1);

        ExamDetailsLayout->setWidget(4, QFormLayout::LabelRole, EndTime);

        endTimeValueLabel = new QLabel(formLayoutWidget);
        endTimeValueLabel->setObjectName("endTimeValueLabel");

        ExamDetailsLayout->setWidget(4, QFormLayout::FieldRole, endTimeValueLabel);

        examValueLabel = new QLabel(formLayoutWidget);
        examValueLabel->setObjectName("examValueLabel");

        ExamDetailsLayout->setWidget(0, QFormLayout::FieldRole, examValueLabel);

        roomValueLabel = new QLabel(formLayoutWidget);
        roomValueLabel->setObjectName("roomValueLabel");

        ExamDetailsLayout->setWidget(1, QFormLayout::FieldRole, roomValueLabel);

        verticalLayoutWidget = new QWidget(generatereport);
        verticalLayoutWidget->setObjectName("verticalLayoutWidget");
        verticalLayoutWidget->setGeometry(QRect(50, 260, 331, 80));
        ProctorsLayout = new QVBoxLayout(verticalLayoutWidget);
        ProctorsLayout->setObjectName("ProctorsLayout");
        ProctorsLayout->setContentsMargins(0, 0, 0, 0);
        Proctors = new QLabel(verticalLayoutWidget);
        Proctors->setObjectName("Proctors");
        Proctors->setFont(font1);

        ProctorsLayout->addWidget(Proctors);

        proctorValueLabel = new QLabel(verticalLayoutWidget);
        proctorValueLabel->setObjectName("proctorValueLabel");
        proctorValueLabel->setFont(font1);

        ProctorsLayout->addWidget(proctorValueLabel);

        formLayoutWidget_2 = new QWidget(generatereport);
        formLayoutWidget_2->setObjectName("formLayoutWidget_2");
        formLayoutWidget_2->setGeometry(QRect(50, 380, 361, 121));
        ExamSummaryLayout = new QFormLayout(formLayoutWidget_2);
        ExamSummaryLayout->setObjectName("ExamSummaryLayout");
        ExamSummaryLayout->setContentsMargins(0, 0, 0, 0);
        TotalPresent = new QLabel(formLayoutWidget_2);
        TotalPresent->setObjectName("TotalPresent");
        TotalPresent->setFont(font1);

        ExamSummaryLayout->setWidget(1, QFormLayout::LabelRole, TotalPresent);

        totalPresentValueLabel = new QLabel(formLayoutWidget_2);
        totalPresentValueLabel->setObjectName("totalPresentValueLabel");

        ExamSummaryLayout->setWidget(1, QFormLayout::FieldRole, totalPresentValueLabel);

        EarlySubmissions = new QLabel(formLayoutWidget_2);
        EarlySubmissions->setObjectName("EarlySubmissions");
        EarlySubmissions->setFont(font1);

        ExamSummaryLayout->setWidget(2, QFormLayout::LabelRole, EarlySubmissions);

        earlySubmissionsValueLabel = new QLabel(formLayoutWidget_2);
        earlySubmissionsValueLabel->setObjectName("earlySubmissionsValueLabel");

        ExamSummaryLayout->setWidget(2, QFormLayout::FieldRole, earlySubmissionsValueLabel);

        BreaksTaken = new QLabel(formLayoutWidget_2);
        BreaksTaken->setObjectName("BreaksTaken");
        BreaksTaken->setFont(font1);

        ExamSummaryLayout->setWidget(3, QFormLayout::LabelRole, BreaksTaken);

        breaksValueLabel = new QLabel(formLayoutWidget_2);
        breaksValueLabel->setObjectName("breaksValueLabel");

        ExamSummaryLayout->setWidget(3, QFormLayout::FieldRole, breaksValueLabel);

        Summary = new QLabel(formLayoutWidget_2);
        Summary->setObjectName("Summary");
        QFont font2;
        font2.setPointSize(14);
        Summary->setFont(font2);

        ExamSummaryLayout->setWidget(0, QFormLayout::LabelRole, Summary);

        verticalLayoutWidget_3 = new QWidget(generatereport);
        verticalLayoutWidget_3->setObjectName("verticalLayoutWidget_3");
        verticalLayoutWidget_3->setGeometry(QRect(50, 590, 801, 171));
        IncidentReport = new QVBoxLayout(verticalLayoutWidget_3);
        IncidentReport->setObjectName("IncidentReport");
        IncidentReport->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(verticalLayoutWidget_3);
        label_2->setObjectName("label_2");
        label_2->setFont(font1);

        IncidentReport->addWidget(label_2);

        GenerateReportButton = new QPushButton(generatereport);
        GenerateReportButton->setObjectName("GenerateReportButton");
        GenerateReportButton->setGeometry(QRect(290, 790, 171, 31));
        GenerateReportButton->setFont(font1);
        pushButton = new QPushButton(generatereport);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(470, 790, 131, 31));
        pushButton->setFont(font1);
        label = new QLabel(generatereport);
        label->setObjectName("label");
        label->setGeometry(QRect(50, 550, 799, 31));
        label->setFont(font2);

        retranslateUi(generatereport);

        QMetaObject::connectSlotsByName(generatereport);
    } // setupUi

    void retranslateUi(QWidget *generatereport)
    {
        generatereport->setWindowTitle(QCoreApplication::translate("generatereport", "generatereport", nullptr));
        Title->setText(QCoreApplication::translate("generatereport", "Exam Report", nullptr));
        Exam->setText(QCoreApplication::translate("generatereport", "Exam:", nullptr));
        Room->setText(QCoreApplication::translate("generatereport", "Room:", nullptr));
        Date->setText(QCoreApplication::translate("generatereport", "Date:", nullptr));
        dateValueLabel->setText(QString());
        StartTime->setText(QCoreApplication::translate("generatereport", "Start Time:", nullptr));
        startTimeValueLabel->setText(QString());
        EndTime->setText(QCoreApplication::translate("generatereport", "End Time:", nullptr));
        endTimeValueLabel->setText(QString());
        examValueLabel->setText(QString());
        roomValueLabel->setText(QString());
        Proctors->setText(QCoreApplication::translate("generatereport", "Proctors:", nullptr));
        proctorValueLabel->setText(QString());
        TotalPresent->setText(QCoreApplication::translate("generatereport", "Total Present:", nullptr));
        totalPresentValueLabel->setText(QString());
        EarlySubmissions->setText(QCoreApplication::translate("generatereport", "Early Submissions:", nullptr));
        earlySubmissionsValueLabel->setText(QString());
        BreaksTaken->setText(QCoreApplication::translate("generatereport", "Breaks Taken:", nullptr));
        breaksValueLabel->setText(QString());
        Summary->setText(QCoreApplication::translate("generatereport", "Summary", nullptr));
        label_2->setText(QString());
        GenerateReportButton->setText(QCoreApplication::translate("generatereport", "Generate Report", nullptr));
        pushButton->setText(QCoreApplication::translate("generatereport", "Close", nullptr));
        label->setText(QCoreApplication::translate("generatereport", "Incident Report:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class generatereport: public Ui_generatereport {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GENERATEREPORT_H
